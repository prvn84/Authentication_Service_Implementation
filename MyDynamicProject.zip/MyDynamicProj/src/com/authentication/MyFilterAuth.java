package com.authentication;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class MyFilterAuth
 */
@WebFilter("/MyFilterAuth")
public class MyFilterAuth implements Filter {

    public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		PrintWriter out=response.getWriter();
		String password=request.getParameter("password");
		String username=request.getParameter("name");
		if(password.equals("admin"))
		{
		
		chain.doFilter(request, response);
	}
		else
		{
			out.print("Incorrect username and password");
			RequestDispatcher rd=request.getRequestDispatcher("index1.html");
			rd.include(request,response);
		}
		}
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	
}
