					Authentication Service Implementation

BASED ON AUTHENTICATION FILTER:

The check case is only made for password , so the page loads for the password = "admin".